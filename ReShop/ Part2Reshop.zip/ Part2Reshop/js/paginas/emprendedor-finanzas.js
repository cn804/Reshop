'use strict';
/* Fuera del alcance del prototipo (sin carrito, pagos ni finanzas): se usa el flujo de reservas */
location.replace('emprendedor-panel.html');
