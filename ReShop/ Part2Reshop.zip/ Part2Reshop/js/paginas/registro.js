'use strict';
/* Registro de clientes y emprendedores */

const form = document.getElementById('form-registro');
const camposNegocio = document.getElementById('campos-negocio');
const destino = UI.destinoSeguro(UI.param('next'));
const yaConectado = Auth.actual();

function actualizarRol() {
    camposNegocio.classList.toggle('oculto', form.rol.value !== 'emprendedor');
}

if (yaConectado) {
    location.replace(Auth.inicioDeRol(yaConectado.rol));
} else {
    if (UI.param('rol') === 'emprendedor') form.querySelector('[value="emprendedor"]').checked = true;
    if (destino) document.getElementById('ir-login').href = 'login.html?next=' + encodeURIComponent(destino);
    actualizarRol();

    form.addEventListener('change', e => {
        if (e.target.name === 'rol') actualizarRol();
    });

    form.addEventListener('submit', e => {
        e.preventDefault();
        let r;
        try {
            r = Auth.registrar(UI.datosFormulario(form));
        } catch (error) {
            r = { ok: false, errores: { general: error.message } };
        }
        if (!r.ok) return UI.mostrarErrores(form, r.errores);
        const inicio = Auth.inicioDeRol(r.usuario.rol);
        location.href = (destino || inicio) + ((destino || inicio).includes('?') ? '&' : '?') + 'aviso=bienvenida';
    });

    UI.iniciar({ refrescar: false });
}
