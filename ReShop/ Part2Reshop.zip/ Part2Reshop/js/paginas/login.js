'use strict';
/* Inicio de sesión */

const form = document.getElementById('form-login');
const destino = UI.destinoSeguro(UI.param('next'));
const yaConectado = Auth.actual();

if (yaConectado) {
    location.replace(destino || Auth.inicioDeRol(yaConectado.rol));
} else {
    /* Conservar el destino si el usuario decide registrarse */
    if (destino) document.getElementById('ir-registro').href = 'registro.html?next=' + encodeURIComponent(destino);

    form.addEventListener('submit', e => {
        e.preventDefault();
        const d = UI.datosFormulario(form);
        const r = Auth.iniciarSesion(d.email, d.password);
        if (!r.ok) return UI.mostrarErrores(form, r.errores);
        location.href = destino || Auth.inicioDeRol(r.usuario.rol);
    });

    UI.iniciar({ refrescar: false });
}
