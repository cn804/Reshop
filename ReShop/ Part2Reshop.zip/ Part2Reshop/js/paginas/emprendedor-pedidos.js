'use strict';
/* Pedidos recibidos por el emprendedor */

const lista = document.getElementById('pedidos');
const filtroEstado = document.getElementById('filtro-estado');

function render() {
    const u = Auth.actual();
    UI.subnavEmprendedor('pedidos');

    const pedidos = Pedidos.delVendedor(u.id);
    const actual = filtroEstado.value || 'todos';
    filtroEstado.innerHTML = [['todos', `Todos (${pedidos.length})`]]
        .concat(Pedidos.ESTADOS.map(e => [e, `${e} (${pedidos.filter(p => p.estado === e).length})`]))
        .map(([valor, texto]) => `<option value="${valor}">${texto}</option>`).join('');
    filtroEstado.value = actual;

    const visibles = actual === 'todos' ? pedidos : pedidos.filter(p => p.estado === actual);
    lista.innerHTML = visibles.length
        ? visibles.map(p => UI.pedido(p, u)).join('')
        : pedidos.length
            ? '<p class="texto-gris">No hay reservas con este estado.</p>'
            : UI.vacio('Todavía no recibes reservas', 'Cuando un cliente reserve tus productos, aparecerán aquí.',
                'emprendedor-productos.html', 'Revisar mis productos');
}

filtroEstado.addEventListener('change', render);

if (UI.iniciar({ rol: 'emprendedor', render })) {
    UI.conectarAccionesPedidos(lista, render);
}
