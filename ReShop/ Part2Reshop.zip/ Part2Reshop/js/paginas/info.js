'use strict';
/* Página informativa (términos, privacidad, contacto, blog) */

UI.iniciar({});
