'use strict';
/* Crear o editar un producto (con imagen de galería o subida) */

const form = document.getElementById('form-producto');
const vistaPrevia = document.getElementById('vista-previa');
const inputImagen = document.getElementById('imagen');
const productoId = UI.param('id');

function ponerImagen(src) {
    inputImagen.value = src || '';
    vistaPrevia.src = src || 'img/categoria-todos.png';
    form.querySelectorAll('[name="galeria"]').forEach(r => { r.checked = r.value === src; });
}

/* Reduce la imagen subida para que quepa en LocalStorage */
function reducirImagen(archivo, maximo) {
    return new Promise((resolver, rechazar) => {
        if (!archivo.type.startsWith('image/')) return rechazar(new Error('El archivo debe ser una imagen.'));
        if (archivo.size > 10 * 1024 * 1024) return rechazar(new Error('La imagen supera 10 MB.'));
        const url = URL.createObjectURL(archivo);
        const img = new Image();
        img.onload = () => {
            const escala = Math.min(1, maximo / Math.max(img.width, img.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.round(img.width * escala);
            canvas.height = Math.round(img.height * escala);
            canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
            URL.revokeObjectURL(url);
            resolver(canvas.toDataURL('image/jpeg', 0.75));
        };
        img.onerror = () => {
            URL.revokeObjectURL(url);
            rechazar(new Error('No se pudo leer la imagen.'));
        };
        img.src = url;
    });
}

function preparar() {
    const u = Auth.actual();
    UI.subnavEmprendedor('productos');

    document.getElementById('categoria').innerHTML = '<option value="">Elige una categoría</option>' +
        CATEGORIAS.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');

    document.getElementById('galeria').innerHTML = GALERIA_IMAGENES.map((src, i) => `
        <label title="Imagen ${i + 1}">
            <input type="radio" name="galeria" value="${src}" aria-label="Imagen ${i + 1}">
            <img src="${src}" alt="" loading="lazy">
        </label>`).join('');

    let producto = null;
    if (productoId) {
        producto = Productos.porId(productoId);
        if (!producto || producto.sellerId !== u.id) {
            form.innerHTML = UI.vacio('Producto no encontrado', 'No existe o no pertenece a tu negocio.',
                'emprendedor-productos.html', 'Volver a mis productos');
            return;
        }
    }

    document.getElementById('encabezado').innerHTML = `
        <div class="pagina-encabezado">
            <div>
                <h1>${producto ? 'Editar producto' : 'Nuevo producto'}</h1>
                <p>${producto ? 'Los cambios se reflejan de inmediato en el catálogo.' : 'Publica un excedente de tu negocio.'}</p>
            </div>
        </div>`;

    if (producto) {
        ['nombre', 'descripcion', 'categoria', 'precio', 'stock', 'disponibleHasta'].forEach(c => {
            form[c].value = producto[c] == null ? '' : producto[c];
        });
        form.precioOriginal.value = producto.precioOriginal == null ? '' : producto.precioOriginal;
        form.activo.checked = producto.activo;
    }
    ponerImagen(producto ? producto.imagen : '');
}

form.addEventListener('change', async e => {
    if (e.target.name === 'galeria') {
        ponerImagen(e.target.value);
        document.getElementById('archivo').value = '';
    }
    if (e.target.id === 'archivo' && e.target.files[0]) {
        try {
            ponerImagen(await reducirImagen(e.target.files[0], 800));
        } catch (error) {
            UI.mostrarErrores(form, { imagen: error.message });
            e.target.value = '';
        }
    }
});

form.addEventListener('submit', e => {
    e.preventDefault();
    const datos = UI.datosFormulario(form);
    datos.activo = form.activo.checked;
    let r;
    try {
        r = Productos.guardar(Auth.actual().id, datos, productoId);
    } catch (error) {
        r = { ok: false, errores: { general: error.message } };
    }
    if (!r.ok) return UI.mostrarErrores(form, r.errores);
    location.href = 'emprendedor-productos.html?aviso=guardado';
});

UI.iniciar({ rol: 'emprendedor', render: preparar, refrescar: false });
