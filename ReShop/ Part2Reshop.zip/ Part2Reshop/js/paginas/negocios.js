'use strict';
/* Lista de negocios registrados */

UI.iniciar({
    seccion: 'negocios',
    render() {
        const publicados = Productos.publicados();
        const negocios = Auth.usuarios().filter(u => u.rol === 'emprendedor');
        document.getElementById('negocios').innerHTML = negocios.length
            ? negocios.map(n => {
                const total = publicados.filter(p => p.sellerId === n.id).length;
                return `
                    <article class="panel negocio-tarjeta">
                        <h2>${UI.esc(n.negocio.nombre)}</h2>
                        <p class="texto-gris">${UI.esc(n.negocio.direccion)}</p>
                        <p>${total} producto${total === 1 ? '' : 's'} publicado${total === 1 ? '' : 's'}</p>
                        <a href="explorar.html?vendedor=${encodeURIComponent(n.id)}" class="boton boton-secundario">Ver productos</a>
                    </article>`;
            }).join('')
            : UI.vacio('Aún no hay negocios registrados', '¿Tienes un negocio con excedentes? Únete a ReShop.',
                'registro.html?rol=emprendedor', 'Registrar mi negocio');
    }
});
