'use strict';
/* Gestión del catálogo: activar/desactivar, inventario, editar y eliminar */

const lista = document.getElementById('lista');
const filtroEstado = document.getElementById('filtro-estado');

function render() {
    const u = Auth.actual();
    UI.subnavEmprendedor('productos');

    const todos = Productos.deVendedor(u.id).sort((a, b) => b.creadoEn.localeCompare(a.creadoEn));
    const productos = todos.filter(p =>
        filtroEstado.value === 'todos' || (filtroEstado.value === 'activos') === p.activo);

    document.getElementById('conteo').textContent =
        `${todos.filter(p => p.activo).length} publicados de ${todos.length}`;

    if (!todos.length) {
        lista.innerHTML = UI.vacio('Aún no tienes productos', 'Publica tu primer excedente para que los clientes lo encuentren.',
            'emprendedor-producto-form.html', 'Crear producto');
        return;
    }
    if (!productos.length) {
        lista.innerHTML = '<p class="texto-gris">No hay productos con este filtro.</p>';
        return;
    }

    lista.innerHTML = productos.map(p => `
        <div class="admin-producto${p.activo ? '' : ' inactivo'}">
            <img src="${UI.esc(p.imagen)}" alt="">
            <div>
                <h3>${UI.esc(p.nombre)}</h3>
                <p class="texto-gris">${UI.esc(nombreCategoria(p.categoria))} · ${UI.dinero(p.precio)}${p.precioOriginal ? ` <del>${UI.dinero(p.precioOriginal)}</del>` : ''}</p>
                <p class="espacio-arriba">${UI.estado(p.activo ? 'Activo' : 'Inactivo')}
                    ${p.stock <= Productos.STOCK_BAJO ? `<span class="problema texto-gris">${p.stock === 0 ? 'Agotado' : 'Inventario bajo'}</span>` : ''}</p>
            </div>
            <div class="acciones-fila">
                <form class="stock-form" data-stock="${p.id}">
                    <label class="texto-gris" for="stock-${p.id}">Inventario</label>
                    <input type="number" id="stock-${p.id}" name="stock" min="0" step="1" value="${p.stock}">
                    <button type="submit" class="boton boton-chico boton-secundario">Guardar</button>
                </form>
                <button type="button" class="boton boton-chico boton-oscuro" data-alternar="${p.id}">${p.activo ? 'Desactivar' : 'Activar'}</button>
                <a href="emprendedor-producto-form.html?id=${p.id}" class="boton boton-chico boton-secundario">Editar</a>
                <a href="producto.html?id=${p.id}" class="boton boton-chico boton-secundario">Ver</a>
                <button type="button" class="boton boton-chico boton-peligro" data-eliminar="${p.id}">Eliminar</button>
            </div>
        </div>`).join('');
}

function resultado(r, mensajeOk) {
    UI.toast(r.ok ? mensajeOk : r.mensaje, r.ok ? 'exito' : 'error');
    render();
}

lista.addEventListener('click', e => {
    const u = Auth.actual();
    const alternar = e.target.closest('[data-alternar]');
    if (alternar) {
        const r = Productos.alternarActivo(alternar.dataset.alternar, u.id);
        resultado(r, r.ok && r.producto.activo ? 'Producto publicado en el catálogo.' : 'Producto ocultado del catálogo.');
    }
    const eliminar = e.target.closest('[data-eliminar]');
    if (eliminar && confirm('¿Eliminar este producto? Los pedidos anteriores conservarán su información.')) {
        resultado(Productos.eliminar(eliminar.dataset.eliminar, u.id), 'Producto eliminado.');
    }
});

lista.addEventListener('submit', e => {
    const form = e.target.closest('[data-stock]');
    if (!form) return;
    e.preventDefault();
    resultado(Productos.ajustarStock(form.dataset.stock, Auth.actual().id, form.stock.value), 'Inventario actualizado.');
});

filtroEstado.addEventListener('change', render);

UI.iniciar({ rol: 'emprendedor', render });
