'use strict';
/* Panel del emprendedor: indicadores calculados con sus propios datos */

function render() {
    const u = Auth.actual();
    const r = Pedidos.resumen(u.id);
    UI.subnavEmprendedor('panel');

    document.getElementById('encabezado').innerHTML = `
        <div class="pagina-encabezado">
            <div>
                <h1>Hola, ${UI.esc(u.nombre)}</h1>
                <p>${UI.esc(u.negocio.nombre)} · ${UI.esc(u.negocio.direccion)}</p>
            </div>
            <a href="emprendedor-producto-form.html" class="boton">+ Nuevo producto</a>
        </div>`;

    document.getElementById('indicadores').innerHTML =
        UI.kpi('Productos publicados', r.publicados, `de ${r.totalProductos} en tu catálogo`) +
        UI.kpi('Inventario disponible', r.inventario, 'unidades en productos activos') +
        UI.kpi('Reservas recibidas', r.totalReservas, `${r.pendientes} pendientes · ${r.aceptadas} aceptadas`) +
        UI.kpi('Reservas entregadas', r.completadas, `${r.unidadesEntregadas} unidades rescatadas`, true);

    document.getElementById('populares').innerHTML = UI.listaVendidos(r.masVendidos);
    document.getElementById('bajo').innerHTML = UI.listaInventarioBajo(r.inventarioBajo);

    document.getElementById('recientes').innerHTML = r.recientes.length
        ? `<div class="lista">${r.recientes.map(p => `
            <div class="lista-fila">
                <div class="crece"><strong>${UI.esc(p.codigo)}</strong><div class="texto-gris">${UI.esc(p.comprador.nombre)} · ${UI.fecha(p.creadoEn)}</div></div>
                <strong>${UI.dinero(p.total)}</strong>
                ${UI.estado(p.estado)}
            </div>`).join('')}</div>
            <p class="espacio-arriba"><a href="emprendedor-pedidos.html" class="enlace">Gestionar reservas →</a></p>`
        : '<p class="texto-gris">Todavía no recibes reservas.</p>';
}

UI.iniciar({ rol: 'emprendedor', render });
