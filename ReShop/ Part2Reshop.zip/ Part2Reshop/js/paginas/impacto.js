'use strict';
/* Impacto global calculado con pedidos entregados */

UI.iniciar({
    seccion: 'impacto',
    render() {
        const i = Pedidos.impacto();
        document.getElementById('indicadores').innerHTML =
            UI.kpi('Productos rescatados', i.rescatados, 'unidades entregadas', true) +
            UI.kpi('Dinero ahorrado', UI.dinero(i.ahorro), 'frente al precio original') +
            UI.kpi('Negocios participantes', i.negocios) +
            UI.kpi('Reservas completadas', i.completadas);
    }
});
